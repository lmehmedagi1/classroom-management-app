function ucitajOsoblje(){
    Pozivi.vratiListuOsoblja();
}
setInterval('ucitajOsoblje()', 30000);