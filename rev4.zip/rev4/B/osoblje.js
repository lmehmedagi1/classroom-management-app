Pozivi.ucitajOsobljeSale();

var interval = setInterval(Pozivi.ucitajOsobljeSale, 30000);



