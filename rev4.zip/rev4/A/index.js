const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const db = require(__dirname+'/db/init.js');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.get('/',(request, response)=>{
    response.redirect('/pocetna.html');
});

const getZauzeca = async () => {
    let periodicne = await getTermini(true);
    let vanredne = await getTermini(false);
    let periodicna = periodicneRezervacijeToZauzeca(periodicne)
    let vanredna = vanredneRezervacijeToZauzeca(vanredne)
    const result = {
        'vanredna':vanredna,
        'periodicna':periodicna
    }
    return result;
}

app.post('/zauzeca',async (req,res) => {
    let result = await getZauzeca();
    if (!req.body.tip){
        res.json(result);
    }else{
        res.json(result[req.body.tip]);
    }
});

app.post('/slike',(req,res) => {
    fs.readdir(__dirname+'/public/img', (err, files) => {
        const index = req.body.lastIndex;
        let result = [];
        for(let i = 0; i<files.length; i+=3){
            myChunk = files.slice(i,i+3);
            result.push(myChunk);
        }
        res.json({images:result[index],size:result.length});
      });
});

app.post('/zauzece',async (req,res)=>{
    let zauzece = req.body;
    let zauzeca = [];
    let vanredno={};
    ({ zauzeca, vanredno, periodicno } = convertToUsual(zauzece, res, zauzeca, vanredno));
    let periodicne = await getTermini(true);
    let vanredne = await getTermini(false);
    let test_periodicna = periodicneRezervacijeToZauzeca(periodicne)
    let test_vanredna = vanredneRezervacijeToZauzeca(vanredne)
    test_periodicna.forEach(element => {
        let converted = convertPeriodicnoToVanredna(element);
        test_vanredna = [...test_vanredna, ...converted];
        });
    let wrong = false;
    let osoba = null;
    zauzeca.forEach(zauzece => {
        let result = koJeZauzeo(zauzece.naziv,new Number(zauzece.datum.split('.')[1]),zauzece.pocetak,zauzece.kraj,new Number(zauzece.datum.split('.')[0]),test_vanredna); 
        if( result.zauzeto){
            wrong = true;
            osoba = result.osoba;
        }
    })
    if(wrong){
        res.json({message:`Salu je zauzeo ${osoba.data}.`})
    }else{
        if(zauzece.periodicno){
            let termin = await db.Termin.create(
                {
                    redovni:true,
                    dan:periodicno.dan,
                    datum:null,
                    semestar:periodicno.semestar,
                    pocetak:periodicno.pocetak,
                    kraj:periodicno.kraj
                }
            )    
            let sala = await db.Sala.findOne({
                where:{
                    naziv:periodicno.naziv
                }
            })
        
            await db.Rezervacija.create(
                {
                    termin:termin.id,
                    sala:sala.id,
                    osoba:periodicno.predavac.value        
                }
            )
        }else{
            let termin = await db.Termin.create(
                {
                    redovni:false,
                    dan:null,
                    datum:vanredno.datum,
                    semestar:null,
                    pocetak:vanredno.pocetak,
                    kraj:vanredno.kraj
                }
            )
            let sala = await db.Sala.findOne({
                    where:{
                        naziv:vanredno.naziv
                    }
                })
            
            await db.Rezervacija.create(
                {
                    termin:termin.id,
                    sala:sala.id,
                    osoba:vanredno.predavac.value        
                }
            )
        }
        let result = await getZauzeca();
        res.json(result);
    }
});

app.get('/osoblje',(req,res) => {
    db.Osoblje.findAll().then(
        (osoblje) => {
            osoblje.map(osoba => {
                return {
                    id:osoba.id,
                    ime:osoba.ime,
                    prezime:osoba.prezime
                }
            })
            res.json({
                osoblje:osoblje
            })
        }
    )
});

app.get('/sale', async (req,res) => {
    db.Sala.findAll().then(
        sale => {
            sale = sale.map( sala => {
                return {value:sala.id,data:sala.naziv}
            })
            res.json({sale:sale})
        }
    )
})

function periodicneRezervacijeToZauzeca(periodicne) {
    return periodicne.map(rezervacija => {
        return {
            dan: rezervacija.Termin.dan,
            semestar: rezervacija.Termin.semestar,
            pocetak: rezervacija.Termin.pocetak,
            kraj: rezervacija.Termin.kraj,
            naziv: rezervacija.Sala.naziv,
            predavac: { value: rezervacija.Osoblje.id, data: rezervacija.Osoblje.ime + ' ' + rezervacija.Osoblje.prezime }
        };
    });
}

function vanredneRezervacijeToZauzeca(vanredne) {
    return vanredne.map(rezervacija => {
        return {
            datum: rezervacija.Termin.datum,
            pocetak: rezervacija.Termin.pocetak,
            kraj: rezervacija.Termin.kraj,
            naziv: rezervacija.Sala.naziv,
            predavac: { value: rezervacija.Osoblje.id, data: rezervacija.Osoblje.ime + ' ' + rezervacija.Osoblje.prezime }
        };
    });
}

function convertToUsual(zauzece, res, zauzeca, vanredno) {
    let periodicno = {}
    if (zauzece.periodicno) {
        if (zauzece.mjesec == 0 || zauzece.mjesec > 8) {
            periodicno.semestar = 'zimski';
        }
        else if (zauzece.mjesec > 0 && zauzece.mjesec < 6) {
            periodicno.semestar = 'ljetni';
        }
        else {
            res.json({ message: 'Error' });
        }
        periodicno.naziv = zauzece.sala;
        periodicno.predavac = zauzece.osoba;
        periodicno.pocetak = zauzece.pocetak;
        periodicno.kraj = zauzece.kraj;
        periodicno.dan = new Date(new Date().getFullYear(), zauzece.mjesec, zauzece.datum).getDay() - 1;
        if (periodicno.dan < 0)
            periodicno.dan = 6;
        zauzeca = [...convertPeriodicnoToVanredna(periodicno)];
    }
    else {
        vanredno = {
            datum: `${zauzece.datum}.${zauzece.mjesec + 1}.${new Date().getFullYear()}`,
            pocetak: zauzece.pocetak,
            kraj: zauzece.kraj,
            naziv: zauzece.sala,
            predavac: zauzece.osoba
        };
        zauzeca.push(vanredno);
    }
    return { zauzeca, vanredno, periodicno };
}

function convertPeriodicnoToVanredna(periodicno){
    let zauzeca = [];
    if(periodicno.semestar === 'zimski'){
        for(let mjesec = 9; mjesec<12; mjesec++){
            zauzeca.push(...makeZauzeca(mjesec, periodicno));
        }
        //ovdje treba i za januar
        zauzeca.push(...makeZauzeca(0,periodicno));
    }else if(periodicno.semestar === 'ljetni'){
        for(let mjesec = 1; mjesec<6; mjesec++){
            zauzeca.push(...makeZauzeca(mjesec,periodicno));
        }
    }
    return zauzeca;
}

function makeZauzeca(mjesec,zauzece){
    const godina = new Date().getFullYear();
    const broj_dana = new Date(godina, mjesec+1,0).getDate();
    zauzeca = [];
    for(let i = 1; i<=broj_dana; i++){
        let dan = new Date(godina, mjesec,i).getDay() - 1;
        if (dan < 0)dan = 6;
        if (dan == zauzece.dan){
            zauzeca.push({
                datum:`${i}.${mjesec+1}.${godina}`,
                pocetak:zauzece.pocetak,
                kraj:zauzece.kraj,
                naziv:zauzece.naziv,
                predavac:zauzece.predavac
            })
        }
    }
    return zauzeca;
}


function koJeZauzeo(sala,mjesec,pocetak,kraj,datum,zauzeca){
    let trenutnaZauzeca = zauzeca.filter(zauzece => {
        const a = zauzece.datum.split('.')[1];
        const b = mjesec+"";
        return a==b && sala == zauzece.naziv;
    });
    
    trenutnaZauzeca = trenutnaZauzeca.filter(zauzece => {
        const [refPocetakH,refPocetakM] = pocetak.split(':').map(broj => new Number(broj));
        const [refKrajH,refKrajM] = kraj.split(':').map(broj => new Number(broj));
        const [PocetakH,PocetakM] = zauzece.pocetak.split(':').map(broj => new Number(broj));
        const [KrajH,KrajM] = zauzece.kraj.split(':').map(broj => new Number(broj));
        const refPocetak = refPocetakH+refPocetakM/60.00;
        const Pocetak = PocetakH+PocetakM/60.00;
        const refKraj = refKrajH+refKrajM/60.00;
        const Kraj = KrajH+KrajM/60.00;
        return !(Pocetak >= refKraj || Kraj <= refPocetak);
    });
    
    const occupation = trenutnaZauzeca.filter(zauzece => {
        const [day,,] = zauzece.datum.split('.');
        return day == datum;
    });
    if(occupation.length === 0){
        return {zauzeto:false,osoba:null};
    }else{
        return {zauzeto:true,osoba:occupation[0].predavac};
    }
}

async function getTermini(isRedovni){
    return await db.Rezervacija.findAll({
        include:[
            {
                model:db.Osoblje
            },
            {
                model:db.Sala
            },
            {
                model:db.Termin,
                where:{
                    redovni:isRedovni
                }
            }
        ]
    })
}


db.init().then(
    () => {
        console.log('Listening on port 8080 after database initialization...')
        app.listen(8080);
        app.emit('start');
    }
)

module.exports = app;






