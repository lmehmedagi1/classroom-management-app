const Sequelize = require('sequelize');
const sequelize = new Sequelize("DBWT19","root","root",
{host:'127.0.0.1',dialect:'mysql',logging:false});

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;
db.Osoblje = sequelize.import(__dirname+'/../models/Osoblje.js');
db.Rezervacija = sequelize.import(__dirname+'/../models/Rezervacija.js');
db.Sala = sequelize.import(__dirname+'/../models/Sala.js');
db.Termin = sequelize.import(__dirname+'/../models/Termin.js');

db.Osoblje.hasOne(db.Sala,{foreignKey:'zaduzenaOsoba'});
db.Sala.belongsTo(db.Osoblje,{foreignKey:'zaduzenaOsoba'});

db.Termin.hasOne(db.Rezervacija, { foreignKey: { name: 'termin', type: db.Sequelize.INTEGER, unique: true } })
db.Rezervacija.belongsTo(db.Termin,{ foreignKey: { name: 'termin', type: db.Sequelize.INTEGER, unique: true } } )

db.Osoblje.hasMany(db.Rezervacija,{foreignKey:'osoba'});
db.Rezervacija.belongsTo(db.Osoblje,{foreignKey:'osoba'})

db.Sala.hasMany(db.Rezervacija,{foreignKey:'sala'});
db.Rezervacija.belongsTo(db.Sala,{foreignKey:'sala'})

module.exports = db;