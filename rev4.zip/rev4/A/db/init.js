const db = require('./db.js');
db.init = async () => {
    async function initialize(){
        await db.Termin.create({redovni:false,dan:null,datum:'1.1.2020',semestar:null,pocetak:'12:00',kraj:'13:00'})
        await db.Termin.create({redovni:true,dan:0,datum:null,semestar:'zimski',pocetak:'13:00',kraj:'14:00'})    
        await db.Osoblje.create({ime:'Neko',prezime:'Nekić',uloga:'profesor'})
        await db.Osoblje.create({ime:'Drugi',prezime:'Neko',uloga:'asistent'})
        await db.Osoblje.create({ime:'Test',prezime:'Test',uloga:'asistent'})
        await db.Sala.create({naziv:'1-11',zaduzenaOsoba:1})
        await db.Sala.create({naziv:'1-15',zaduzenaOsoba:2})
        await db.Rezervacija.create({termin:1,sala:1,osoba:1})
        await db.Rezervacija.create({termin:2,sala:1,osoba:3})
    };
    await db.sequelize.query('SET FOREIGN_KEY_CHECKS = 0', { raw: true });
    await db.sequelize.sync({force:'true'})
    await initialize();
}


module.exports = db;


