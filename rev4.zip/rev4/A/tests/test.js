let assert = require('assert');
let chai = require('chai');
let chaiHttp = require('chai-http');
chai.use(chaiHttp)
let server = require('../index.js');
let should = chai.should();
let agent = chai.request.agent(server);

before( done => {
    server.on('start',function(){
        done();
    })
})

describe('GET /osoblje', () => {
    describe('Is there any response??',function(){
        it('Should be status 200',function(done){
            chai.request(server)
                .get('/osoblje')
                .end((err,res) => {
                    res.should.have.status(200);
                    done();
                })
        })
    })
    describe('Is there any content in the body?',function(){
        it('Should be an object',function(done){
            chai.request(server)
                .get('/osoblje')
                .end((err,res) => {
                    assert.equal(typeof res.body,'object')
                    done();
                })
        })
    })
    describe('How many objects Osoblje do we get?',function(){
        it('Should be 3',function(done){
            chai.request(server)
                .get('/osoblje')
                .end((err,res) => {
                    assert.equal(res.body.osoblje.length,3)
                    done();
                })
        })
    })
    describe('Who do we get?',function(){
        it('Should have Nekić',function(done){
            chai.request(server)
                .get('/osoblje')
                .end((err,res) => {
                    let prezimena = res.body.osoblje.map(osoba => osoba.prezime).join(' '); 
                    assert.equal(prezimena.includes('Nekić'),true)
                    done();
                })
        })
    })
    
})

describe('Zauzeca', () => {
    describe('Is there any response??',function(){
        it('Should be status 200',function(done){
            chai.request(server)
                .post('/zauzeca')
                .send({})
                .end((err,res) => {
                    res.should.have.status(200);
                    done();
                })
        })
    })
    describe('How many do we get in the beginning?',function(){
        it('Should be 2',function(done){
            chai.request(server)
                .post('/zauzeca')
                .send({})
                .end((err,res) => {
                    let response = res.body;
                    const vanredna = response.vanredna;
                    const periodicna = response.periodicna;
                    assert.equal(periodicna.length+vanredna.length,2)
                    done();
                })
        })
    })
    describe('How many do we get after sending one?',function(){
        it('Should be 3',function(done){
            agent
                .post('/zauzece')
                .send(
                    {
                        sala:'1-11',
                        mjesec:0,
                        pocetak:'08:00',
                        kraj:'09:30',
                        datum:'2',
                        periodicno:false,
                        osoba:{
                            value:1,
                            data:'Neko Nekić'
                        }
                    }
                )
                .then(res => {
                    agent
                        .post('/zauzeca')
                        .send({})
                        .then(res => {
                            let response = res.body;
                            const vanredna = response.vanredna;
                            const periodicna = response.periodicna;
                            assert.equal(periodicna.length+vanredna.length,3)
                            done();
                        })
                })
        })
    })
    describe('Does it store the right date?',function(){
        it('Should be 2.1.2020',function(done){
            agent
                .post('/zauzece')
                .send(
                    {
                        sala:'1-11',
                        mjesec:0,
                        pocetak:'08:00',
                        kraj:'09:30',
                        datum:'2',
                        periodicno:false,
                        osoba:{
                            value:1,
                            data:'Neko Nekić'
                        }
                    }
                )
                .then(res => {
                    agent
                        .post('/zauzeca')
                        .send({})
                        .then(res => {
                            let response = res.body;
                            const vanredna = response.vanredna;
                            assert.equal(vanredna[1].datum,'2.1.2020')
                            done();
                        })
                })
        })
    })
})

describe('GET Sale ', () => {
    describe('How many do we get?',function(){
        it('Should be 2',function(done){
            agent
                .get('/sale')
                .then(res => {
                    const sale = res.body.sale;
                    sale.should.have.length(2,'Not valid size!')
                    done();
                })
        })
    })
    describe('Which ones do we get?',function(){
        it('Should be 1-11 and 1-15',function(done){
            agent
                .get('/sale')
                .then(res => {
                    const sale = res.body.sale.map(sala => sala.data).join(' ');
                    const one = sale.includes('1-11')
                    const two = sale.includes('1-15')
                    assert.equal(one && two, true);
                    done();
                })
        })
    })
})

describe("POST Reservation",() => {
    describe('Can we make a reservation on top of another one?',function(){
        it('Should not be possible!!',function(done){
            agent
                .post('/zauzece')
                .send(
                    {
                        sala:'1-11',
                        mjesec:0,
                        pocetak:'12:00',
                        kraj:'15:30',
                        datum:'1',
                        periodicno:false,
                        osoba:{
                            value:1,
                            data:'Neko Nekić'
                        }
                    }
                )
                .then(res => {
                    const response = res.body;
                    const result = response.message.includes('Salu je zauzeo');
                    assert.equal(result, true);
                    done();
                })
        })
    })
    describe('Can somebody else make a reservation on top of another one?',function(){
        it('Should not be possible!!',function(done){
            agent
                .post('/zauzece')
                .send(
                    {
                        sala:'1-11',
                        mjesec:0,
                        pocetak:'12:00',
                        kraj:'15:30',
                        datum:'1',
                        periodicno:false,
                        osoba:{
                            value:2,
                            data:'Drugi Neko'
                        }
                    }
                )
                .then(res => {
                    const response = res.body;
                    const result = response.message.includes('Salu je zauzeo');
                    assert.equal(result, true);
                    done();
                })
        })
    })
    describe('Can somebody else make a periodic reservation 7 days after(the same day in the week)?',function(){
        it('Should not be possible!!',function(done){
            agent
                .post('/zauzece')
                .send(
                    {
                        sala:'1-11',
                        mjesec:0,
                        pocetak:'12:00',
                        kraj:'15:30',
                        datum:'8',
                        periodicno:true,
                        osoba:{
                            value:3,
                            data:'Test Test'
                        }
                    }
                )
                .then(res => {
                    const response = res.body;
                    const result = response.message.includes('Salu je zauzeo');
                    assert.equal(result, true);
                    done();
                })
        })
    })
    describe('Can somebody else make a periodic reservation 7 days after(the same day in the week) using another room?',function(){
        it('Should be OK',function(done){
            agent
                .post('/zauzece')
                .send(
                    {
                        sala:'1-15',
                        mjesec:0,
                        pocetak:'12:00',
                        kraj:'15:30',
                        datum:'8',
                        periodicno:true,
                        osoba:{
                            value:3,
                            data:'Test Test'
                        }
                    }
                )
                .then(res => {
                    const response = res.body;
                    const result = response.message;
                    assert.equal(result, null);
                    done();
                })
        })
    })
})

