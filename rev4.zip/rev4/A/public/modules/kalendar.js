let Kalendar = (function(){
    'use strict';
    const brojDana = [31,28,31,30,31,30,31,31,30,31,30,31];
    const imenaMjeseci = ["Januar", "Februar", "Mart", "April", "Maj", 
                            "Juni", "Juli", "August", "Septembar", "Oktobar", 
                            "Novembar", "Decembar"];
    let zauzeca = [];
    const getFirstDayOfMonth = (month, year) => {
        let date = new Date();
        date.setFullYear(year);
        date.setMonth(month);
        date.setDate(1);
        let day = date.getUTCDay();
        if(day===0)day=7;
        return day;
    }

    const makeCell = (data, visibility , occupation)=>{
        if(!visibility)visibility='invisible';
        else visibility = '';
        return `<div class="cell ${visibility}" onclick="rezervisi(this)">
                <div class="cell-content">${data}</div>
                <div class="cell-occupation ${occupation}"></div>
                </div>`;
            }
            
    function makeZauzece(mjesec, zauzece) {
        const year = new Date().getFullYear();
        const numberOfDays = new Date(year, mjesec+1, 0).getDate();
        const month = new Date(year,mjesec,1).toLocaleString('bs', { month: 'long' });
        new Array(numberOfDays).fill(0).forEach((_, index) => {
            let dan = new Date(year, mjesec, index + 1).getDay() - 1;
            if (dan < 0)dan = 6;
            if (dan === zauzece.dan) {
                zauzeca.push({
                    datum: `${index + 1}.${mjesec+1}.${year}`,
                    pocetak: zauzece.pocetak,
                    kraj: zauzece.kraj,
                    naziv: zauzece.naziv,
                    predavac: zauzece.predavac
                });
            }
        });
    }
            
    function ucitajPodatke(redovna, vanredna){
        if(vanredna){
            zauzeca = [...vanredna];
        }
        if(redovna){
            ucitajPeriodicnaZauzecaUZauzeca(redovna);
        }
    }
    function ucitajPeriodicnaZauzecaUZauzeca(periodicna){
        periodicna.forEach(zauzece => {
            if(zauzece.semestar === 'zimski'){
                for(let mjesec = 9; mjesec<12; mjesec++){
                    makeZauzece(mjesec, zauzece);
                }
                //ovdje treba i za januar
                makeZauzece(0,zauzece);
            }else if(zauzece.semestar === 'ljetni'){
                for(let mjesec = 1; mjesec<6; mjesec++){
                    makeZauzece(mjesec,zauzece);
                }
            }else{
                console.log(zauzece + ' nije ispravno\n'+'Nepoznat semestar: '+zauzece.semestar);
            }
        });
    }
    function obojiZauzeca(kalendarRef, mjesec, sala, pocetak, kraj){
        let datumi = kalendarRef.getElementsByClassName("datumi")[0];
        let trenutnaZauzeca = zauzeca.filter(zauzece => {
            return new Number(zauzece.datum.split('.')[1]) == (mjesec+1) && sala == zauzece.naziv;
        });
        trenutnaZauzeca = trenutnaZauzeca.filter(zauzece => {
            const [refPocetakH,refPocetakM] = pocetak.split(':').map(broj => new Number(broj));
            const [refKrajH,refKrajM] = kraj.split(':').map(broj => new Number(broj));
            const [PocetakH,PocetakM,] = zauzece.pocetak.split(':').map(broj => new Number(broj));
            const [KrajH,KrajM,] = zauzece.kraj.split(':').map(broj => new Number(broj));
            const refPocetak = refPocetakH+refPocetakM/60.00;
            const Pocetak = PocetakH+PocetakM/60.00;
            const refKraj = refKrajH+refKrajM/60.00;
            const Kraj = KrajH+KrajM/60.00;
            return !(Pocetak >= refKraj || Kraj <= refPocetak);
        });
        datumi.childNodes.forEach(element => {
            if(element.style){
                let date = element.getElementsByClassName("cell-content")[0].innerHTML;
                let occupationCell = element.getElementsByClassName('cell-occupation')[0];
                if(date !== '' ){
                    const occupation = trenutnaZauzeca.filter(zauzece => {
                        let [day,,] = zauzece.datum.split('.');
                        day = new Number(day);
                        day = ''+day;
                        return day === date;
                    });
                    occupationCell.classList.remove('zauzeta');
                    occupationCell.classList.remove('slobodna');
                    
                    if(occupation.length !== 0){
                        occupationCell.classList.add('zauzeta'); 
                    }else{
                        occupationCell.classList.add('slobodna');
                    }
                }
                
            }
        });
    }
    function iscrtajKalendar(kalendarRef, mjesec){
        let hiddenBlocks = getFirstDayOfMonth(mjesec,new Date().getFullYear());
        document.getElementById("mjesec").getElementsByTagName("h2")[0].innerHTML = imenaMjeseci[mjesec];
        let datumi = kalendarRef.getElementsByClassName('datumi')[0];
        let result = "";
        for(let i = 1; i < hiddenBlocks; i++){
            result += makeCell(i,false,'slobodna');
        }
        for(let i = 1; i < brojDana[mjesec]+1; i++){
            result += makeCell(i,true,'slobodna');
        }
        datumi.innerHTML = result;
    }
    function jeLiZauzeto(sala,mjesec,pocetak,kraj,dan){
        let trenutnaZauzeca = zauzeca.filter(zauzece => {
            return new Number(zauzece.datum.split('.')[1]) == (mjesec+1) && sala == zauzece.naziv;
        });
        trenutnaZauzeca = trenutnaZauzeca.filter(zauzece => {
            const [refPocetakH,refPocetakM] = pocetak.split(':').map(broj => new Number(broj));
            const [refKrajH,refKrajM] = kraj.split(':').map(broj => new Number(broj));
            const [PocetakH,PocetakM] = zauzece.pocetak.split(':').map(broj => new Number(broj));
            const [KrajH,KrajM] = zauzece.kraj.split(':').map(broj => new Number(broj));
            const refPocetak = refPocetakH+refPocetakM/60.00;
            const Pocetak = PocetakH+PocetakM/60.00;
            const refKraj = refKrajH+refKrajM/60.00;
            const Kraj = KrajH+KrajM/60.00;
            return !(Pocetak >= refKraj || Kraj <= refPocetak);
        });
        const occupation = trenutnaZauzeca.filter(zauzece => {
            const [day,,] = zauzece.datum.split('.');
            return day === dan;
        });
        if(occupation.length === 0){
            return false;
        }else{
            return true;
        }
    }

    return {
        obojiZauzeca: obojiZauzeca,
        ucitajPodatke: ucitajPodatke,
        iscrtajKalendar: iscrtajKalendar,
        jeLiZauzeto:jeLiZauzeto
    }
}());