let Pozivi = (function(){
    'use strict';
    async function getOsoblje(){
        let response = await fetch('/osoblje');
        return await response.json();
    }
    async function getSale(){
        let response = await fetch('/sale')
        return await response.json()
    }
    async function getZauzeca(){
        const response = await fetch('/zauzeca',{
            method:'POST',
            headers:{
                'Content-Type':'application/json'
            },
            body:JSON.stringify({})
        })
        return await response.json();
    }

    async function sendZauzece(zauzece){
        let response = await fetch('/zauzece',{
            method:'POST',
            headers:{
                'Content-Type':'application/json'
            },
            body:JSON.stringify(zauzece)
        });
        return await response.json();
    }

    async function getNextPictureChunk(lastIndex){
        const response = await fetch('/slike',{
            method:'POST',
            headers:{
                'Content-Type':'application/json'
            },
            body:JSON.stringify({lastIndex:lastIndex})
        })
        return await response.json();
    }

    return {
        sendZauzece,
        getNextPictureChunk,
        getZauzeca,
        getOsoblje,
        getSale
    }
}());