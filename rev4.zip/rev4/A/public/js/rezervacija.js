let mjesec;
let ref;
let inputData = {
    
};

window.onload = () => {
    load();
}

async function load(){
    await getOsoblje()
    await getSale()
    mjesec = new Date().getMonth();
    monthRegulation();
    ref = document.getElementById("kalendar");
    const inputNames = ['sala','pocetak','kraj','periodicna','osoba'];
    inputNames.forEach(name => {
        document.getElementsByName(name)[0].addEventListener('change', (event) => {
            inputChangeHandler(event,name);
        })
        inputChangeHandler(null,name);     
    });
    Kalendar.iscrtajKalendar(ref,mjesec);
    let zauzeca = await Pozivi.getZauzeca();
    Kalendar.ucitajPodatke(zauzeca.periodicna,zauzeca.vanredna)
    Kalendar.obojiZauzeca(ref,mjesec,inputData.sala, inputData.pocetak, inputData.kraj);
}

const getOsoblje = async () => {
    let osobeContainer = document.getElementById('osoba');
    let response = await Pozivi.getOsoblje();
    let osoblje = response.osoblje;
    html = osoblje.map(osoba => `
            <option value="${osoba.id}">
                ${osoba.ime} ${osoba.prezime}
            </option>`).join('\n');
    osobeContainer.innerHTML = html;
}

const getSale = async () => {
    let saleContainer = document.getElementById('sala');
    let result = await Pozivi.getSale();
    const sale = result.sale;
    let html = sale.map(sala => `
            <option value="${sala.data}">
            ${sala.data}</option>`).join('\n');
    saleContainer.innerHTML = html;
}


const inputChangeHandler = (event, name) => {
    if(name === 'osoba'){
        const value = document.getElementById('osoba').value;
        const data = document.getElementById('osoba').innerText;
        inputData[name] = {
            value:value,
            data:data
        }
    }else if(name === 'sala'){
        inputData[name] = document.getElementById('sala').value;
    }else{
        inputData[name] = (name==='periodicna')?document.getElementsByName(name)[0].checked:document.getElementsByName(name)[0].value;
    }
    Kalendar.obojiZauzeca(ref,mjesec,inputData.sala, inputData.pocetak, inputData.kraj);
}

const monthRegulation = () => {
    if(mjesec > 10){
        document.getElementById("sljedeci").disabled = true;
    }else if(mjesec < 1){
        document.getElementById("prethodni").disabled = true;
    }else{
        document.getElementById("prethodni").disabled = false;
        document.getElementById("sljedeci").disabled = false;
    }
}

const sljedeci = () => {
    mjesec++;
    monthRegulation();
    Kalendar.iscrtajKalendar(document.getElementById('kalendar'),mjesec);
    Kalendar.obojiZauzeca(ref,mjesec,inputData.sala, inputData.pocetak, inputData.kraj);
}

const prethodni = () =>{
    mjesec--;
    monthRegulation();
    Kalendar.iscrtajKalendar(document.getElementById('kalendar'),mjesec);
    Kalendar.obojiZauzeca(ref,mjesec,inputData.sala, inputData.pocetak, inputData.kraj);
}

const rezervisi = async (elem) => {
    
    if(confirm("Želite li izvršiti rezervaciju?")){
        const zauzece = {
                sala:inputData.sala,
                mjesec:mjesec,
                pocetak:inputData.pocetak,
                kraj:inputData.kraj,
                datum:elem.getElementsByClassName("cell-content")[0].innerHTML,
                periodicno:inputData.periodicna,
                osoba:inputData.osoba
            };
        let zauzeca = await Pozivi.sendZauzece(zauzece);
        if(zauzeca.message){
            alert(zauzeca.message)
        }else{
            Kalendar.ucitajPodatke(zauzeca["periodicna"],zauzeca["vanredna"]);
            Kalendar.obojiZauzeca(ref,mjesec,inputData.sala,inputData.pocetak,inputData.kraj);
        }
    }else{
        console.log("Kanselujem...");
    }   
}