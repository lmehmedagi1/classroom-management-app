let slike = [

];
let size = 0;

let index = 0;

const prethodniRef = document.getElementById("prethodni");
const sljedeciRef = document.getElementById("sljedeci");

const prethodni = () => {
    index--;
    if(index == 0){
        prethodniRef.disabled = true;
    }
    sljedeciRef.disabled = false;
    displayImages(slike[index]);
}

const sljedeci = async () => {
    index++;
    if(index == size-1){
        sljedeciRef.disabled = true;
    }
    prethodniRef.disabled = false;
    if(index == slike.length){
        let response = await Pozivi.getNextPictureChunk(index);
        loadNext(response.images,response.size);
    }else{
        displayImages(slike[index]);
    }
}

window.onload = async () => {
    index = 0;
    prethodniRef.disabled = true;
    let response = await Pozivi.getNextPictureChunk(index);
    loadNext(response.images,response.size);
}

function loadNext(images,actualSize){
    size = actualSize;
    slike.push(images);
    displayImages(images);
}

function displayImages(images){
    const innerHTML = makeImages(images);
    let gallery = document.getElementById("root");
    gallery.innerHTML = innerHTML;
}

function makeImages(images){
    let result = "";
    images.forEach(fileName => {
        result += makeImage(fileName);
    });
    return result;
}

function makeImage(fileName){
    return `<img src="/img/${fileName}"/>\n`;
}