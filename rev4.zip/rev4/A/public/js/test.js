let assert = chai.assert;
let expect = chai.expect;
describe('Kalendar', function() {
    describe('iscrtajKalendar()', function() {
        it('Treba iscrtat 30 dana', function() {
            let ref = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(ref,3);
            let celije = [...ref.getElementsByClassName("datumi")[0].getElementsByClassName('cell')];
            celije = celije.filter(celija =>{
                let isVisible = true;
                celija.classList.forEach(element => {
                    if(element=='invisible'){
                        isVisible = false;
                    }
                });
                return isVisible;
            });     
            assert.equal(celije.length, 30,"Broj dana treba biti 30");
        });
        it('Treba iscrtat 31 dan', function() {
            let ref = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(ref,0);
            let celije = [...ref.getElementsByClassName("datumi")[0].getElementsByClassName('cell')];
            celije = celije.filter(celija =>{
                let isVisible = true;
                celija.classList.forEach(element => {
                    if(element=='invisible'){
                        isVisible = false;
                    }
                });
                return isVisible;
            });     
            assert.equal(celije.length, 31,"Broj dana treba biti 31");
        });
        it('Prvi dan treba bit petak(Novembar)', function() {
            let ref = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(ref,new Date().getMonth());
            //ako se bude gledalo u decembru, ovdje treba da bude 10 hardkodirano...
            let celije = [...ref.getElementsByClassName("datumi")[0].getElementsByClassName('cell')];
            let isFriday = false;
            celije = celije.forEach((element,index) => {
                if(index==4){
                    //petak
                    let datum = element.getElementsByClassName("cell-content")[0].innerHTML;
                    if(datum == '1'){
                        isFriday = true;
                    }
                }
            });     
            assert.equal(isFriday, true,"Prvi dan u mjesecu treba biti petak");
        });
        it('30. dan treba bit subota(Novembar)', function() {
            let ref = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(ref,new Date().getMonth());
            //ako se bude gledalo u decembru, ovdje treba da bude 10 hardkodirano...
            let celije = [...ref.getElementsByClassName("datumi")[0].getElementsByClassName('cell')];
            let isSaturday = false;
            celije = celije.forEach((element,index) => {
                if(index==33){
                    //subota
                    let datum = element.getElementsByClassName("cell-content")[0].innerHTML;
                    if(datum == '30'){
                        isSaturday = true;
                    }
                }
            });     
            assert.equal(isSaturday, true,"30. dan u mjesecu treba biti subota");
        });
        it('Dani u januaru trebaju da idu od 1 do 31', function() {
            let ref = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(ref,0);
            let dani = '';
            let celije = [...ref.getElementsByClassName("datumi")[0].getElementsByClassName('cell')];
            celije = celije.forEach((element,index) => {
                if(!element.classList.contains('invisible')){
                    let datum = element.getElementsByClassName("cell-content")[0].innerHTML;
                    dani = dani.concat(datum);
                }
            });     
            const ocekivano = '12345678910111213141516171819202122232425262728293031';
            assert.equal(dani, ocekivano,"Očekuje se da dani u januaru idu od 1 do 31");
        });
        it('Februar treba da ima 28 dana', function() {
            let ref = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(ref,1);
            let celije = [...ref.getElementsByClassName("datumi")[0].getElementsByClassName('cell')];
            celije = celije.filter(celija =>{
                let isVisible = true;
                celija.classList.forEach(element => {
                    if(element=='invisible'){
                        isVisible = false;
                    }
                });
                return isVisible;
            });
            assert.equal(celije.length, 28,"Očekuje se da februar ima 28 dana u ovoj godini");
        });
        it('31. Mart treba da bude nedjelja', function() {
            let ref = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(ref,2);
            let celije = [...ref.getElementsByClassName("datumi")[0].getElementsByClassName('cell')];
            let isSunday = false;
            celije = celije.forEach((element,index) => {
                if(index==34){
                    //subota
                    let datum = element.getElementsByClassName("cell-content")[0].innerHTML;
                    if(datum == '31'){
                        isSunday = true;
                    }
                }
            });
            assert.equal(isSunday, true,"Očekuje se da 31. Mart bude nedjelja.");
        });
    });
    describe('obojiZauzeca()', function() {
        it('Pozivanje obojiZauzeca kada podaci nisu učitani:', function(){
            let ref = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(ref,2);
            Kalendar.obojiZauzeca(ref,2,'VA','09:00','11:00');
            let celije = [...ref.getElementsByClassName("datumi")[0].getElementsByClassName('cell')];
            let isOccupied = false;
            celije = celije.forEach((element,index) => {
                let zauzece = element.getElementsByClassName("cell-occupation")[0];
                if(zauzece.classList.contains('zauzeta')){
                    isOccupied = true;
                }
            });
            expect(isOccupied).not.to.be.equal(true);
        });
        it('Pozivanje obojiZauzeca gdje u zauzećima postoje duple vrijednosti za zauzeće istog termina', function(){
            let ref = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(ref,11);
            Kalendar.ucitajPodatke([{
                dan:0,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            },
            {
                dan:0,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            }],
            [
                {
                    datum:'9.12.2019',
                    pocetak:'09:00',
                    kraj:'11:00',
                    naziv:'VA',
                    predavac:'veca'
                }
            ]);
            Kalendar.obojiZauzeca(ref,11,'VA','09:00','11:00');
            let celije = [...ref.getElementsByClassName("datumi")[0].getElementsByClassName('cell')];
            let brojZauzeca = 0;
            celije = celije.forEach((element,index) => {
                    let isInvisible = element.classList.contains('invisible');
                    let zauzece = element.getElementsByClassName("cell-occupation")[0];
                    if(zauzece.classList.contains('zauzeta') && !isInvisible){
                        brojZauzeca++;
                    }
            });
            expect(brojZauzeca).to.be.equal(5);
        });
        it('Pozivanje obojiZauzece kada u podacima postoji periodično zauzeće za drugi semestar', function(){
            let ref = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(ref,3);
            Kalendar.ucitajPodatke([
                {
                    dan:2,
                    semestar:'zimski',
                    pocetak:'09:00',
                    kraj:'11:00',
                    naziv:'VA',
                    predavac:'Jurke'
                }
            ],[

            ]);
            Kalendar.obojiZauzeca(ref,3,'VA','09:00','11:00');
            let celije = [...ref.getElementsByClassName("datumi")[0].getElementsByClassName('cell')];
            let isOccupied = false;
            celije = celije.forEach((element,index) => {
                let zauzece = element.getElementsByClassName("cell-occupation")[0];
                if(zauzece.classList.contains('zauzeta')){
                    isOccupied = true;
                }
            });
            expect(isOccupied).not.to.be.equal(true);
        });
        it('Pozivanje obojiZauzece kada u podacima postoji zauzeće termina ali u drugom mjesecu', function(){
            let ref = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(ref,10);
            Kalendar.ucitajPodatke([
                
            ],[
                {
                    datum:'9.12.2019',
                    pocetak:'09:00',
                    kraj:'11:00',
                    naziv:'VA',
                    predavac:'veca'
                }
            ]);
            Kalendar.obojiZauzeca(ref,10,'VA','09:00','11:00');
            let celije = [...ref.getElementsByClassName("datumi")[0].getElementsByClassName('cell')];
            let isOccupied = false;
            celije = celije.forEach((element,index) => {
                let zauzece = element.getElementsByClassName("cell-occupation")[0];
                if(zauzece.classList.contains('zauzeta')){
                    isOccupied = true;
                }
            });
            expect(isOccupied).not.to.be.equal(true);
        });
        //Pozivanje obojiZauzece kada su u podacima svi termini u mjesecu zauzet
        it('Pozivanje obojiZauzece kada su u podacima svi termini u mjesecu zauzet', function(){
            let ref = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(ref,11);
            Kalendar.ucitajPodatke([
            {
                dan:0,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            },
            {
                dan:1,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            },
            {
                dan:2,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            },
            {
                dan:3,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            },
            {
                dan:4,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            },
            {
                dan:5,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            },
            {
                dan:6,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            }
        ],
            []);
            Kalendar.obojiZauzeca(ref,11,'VA','09:00','11:00');
            let celije = [...ref.getElementsByClassName("datumi")[0].getElementsByClassName('cell')];
            let brojZauzeca = 0;
            celije = celije.forEach((element,index) => {
                    let isInvisible = element.classList.contains('invisible');
                    let zauzece = element.getElementsByClassName("cell-occupation")[0];
                    if(zauzece.classList.contains('zauzeta') && !isInvisible){
                        brojZauzeca++;
                    }
            });
            expect(brojZauzeca).to.be.equal(31);
        });
        it('Dva puta uzastopno pozivanje obojiZauzece', function(){
            let ref = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(ref,11);
            Kalendar.ucitajPodatke([],
            [
                {
                    datum:'9.12.2019',
                    pocetak:'09:00',
                    kraj:'11:00',
                    naziv:'VA',
                    predavac:'veca'
                }
            ]);
            Kalendar.obojiZauzeca(ref,11,'VA','09:00','11:00');
            let celije = [...ref.getElementsByClassName("datumi")[0].getElementsByClassName('cell')];
            let brojZauzeca = 0;
            celije = celije.forEach((element,index) => {
                    let isInvisible = element.classList.contains('invisible');
                    let zauzece = element.getElementsByClassName("cell-occupation")[0];
                    if(zauzece.classList.contains('zauzeta') && !isInvisible){
                        brojZauzeca++;
                    }
            });
            Kalendar.obojiZauzeca(ref,11,'VA','09:00','11:00');
            let celije2 = [...ref.getElementsByClassName("datumi")[0].getElementsByClassName('cell')];
            let brojZauzeca2 = 0;
            celije2 = celije2.forEach((element,index) => {
                    let isInvisible = element.classList.contains('invisible');
                    let zauzece = element.getElementsByClassName("cell-occupation")[0];
                    if(zauzece.classList.contains('zauzeta') && !isInvisible){
                        brojZauzeca2++;
                    }
            });
            expect(brojZauzeca).to.be.equal(brojZauzeca2);
        });
        it('Pozivanje ucitajPodatke, obojiZauzeca, ucitajPodatke - drugi podaci, obojiZauzeca', function(){
            let ref = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(ref,11);
            Kalendar.ucitajPodatke([],
            [
                {
                    datum:'9.12.2019',
                    pocetak:'09:00',
                    kraj:'11:00',
                    naziv:'VA',
                    predavac:'veca'
                }
            ]);
            Kalendar.obojiZauzeca(ref,11,'VA','09:00','11:00');
            let celije = [...ref.getElementsByClassName("datumi")[0].getElementsByClassName('cell')];
            let brojZauzeca = 0;
            celije = celije.forEach((element,index) => {
                    let isInvisible = element.classList.contains('invisible');
                    let zauzece = element.getElementsByClassName("cell-occupation")[0];
                    if(zauzece.classList.contains('zauzeta') && !isInvisible){
                        brojZauzeca++;
                    }
            });
            Kalendar.ucitajPodatke([],
                [
                    {
                        datum:'10.12.2019',
                        pocetak:'09:00',
                        kraj:'11:00',
                        naziv:'VA',
                        predavac:'veca'
                    }
                ]);
            Kalendar.obojiZauzeca(ref,11,'VA','09:00','11:00');
            let celije2 = [...ref.getElementsByClassName("datumi")[0].getElementsByClassName('cell')];
            let brojZauzeca2 = 0;
            celije2 = celije2.forEach((element,index) => {
                    let isInvisible = element.classList.contains('invisible');
                    let zauzece = element.getElementsByClassName("cell-occupation")[0];
                    if(zauzece.classList.contains('zauzeta') && !isInvisible){
                        brojZauzeca2++;
                    }
            });
            expect(brojZauzeca2).not.to.be.equal(brojZauzeca+1);
        });
        it('Pozivanje obojiZauzece za August', function(){
            let ref = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(ref,7);
            Kalendar.ucitajPodatke([
            {
                dan:0,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            },
            {
                dan:1,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            },
            {
                dan:2,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            },
            {
                dan:3,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            },
            {
                dan:4,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            },
            {
                dan:5,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            },
            {
                dan:6,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            }
        ],
            []);
            Kalendar.obojiZauzeca(ref,7,'VA','09:00','11:00');
            let celije = [...ref.getElementsByClassName("datumi")[0].getElementsByClassName('cell')];
            let brojZauzeca = 0;
            celije = celije.forEach((element,index) => {
                    let isInvisible = element.classList.contains('invisible');
                    let zauzece = element.getElementsByClassName("cell-occupation")[0];
                    if(zauzece.classList.contains('zauzeta') && !isInvisible){
                        brojZauzeca++;
                    }
            });
            expect(brojZauzeca).to.be.equal(0);
        });

        it('Pozivanje obojiZauzece kada su zauzeca za drugu salu', function(){
            let ref = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(ref,11);
            Kalendar.ucitajPodatke([
            {
                dan:0,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            },
            {
                dan:1,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            },
            {
                dan:2,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            },
            {
                dan:3,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            },
            {
                dan:4,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            },
            {
                dan:5,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            },
            {
                dan:6,
                semestar:'zimski',
                pocetak:'09:00',
                kraj:'11:00',
                naziv:'VA',
                predavac:'veca'
            }
        ],
            []);
            Kalendar.obojiZauzeca(ref,11,'MA','09:00','11:00');
            let celije = [...ref.getElementsByClassName("datumi")[0].getElementsByClassName('cell')];
            let brojZauzeca = 0;
            celije = celije.forEach((element,index) => {
                    let isInvisible = element.classList.contains('invisible');
                    let zauzece = element.getElementsByClassName("cell-occupation")[0];
                    if(zauzece.classList.contains('zauzeta') && !isInvisible){
                        brojZauzeca++;
                    }
            });
            expect(brojZauzeca).to.be.equal(0);
        });
    });
});
