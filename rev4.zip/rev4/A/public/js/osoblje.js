window.onload = ()=> {
    loadTableOfOsoblje();
    setInterval(() => loadTableOfOsoblje(),30000)
}

async function loadTableOfOsoblje(){
    let zauzeca = await Pozivi.getZauzeca();
    let periodicna = zauzeca.periodicna;
    let vanredna = zauzeca.vanredna;
    let osobe;
    osobe  = await matchOsobeWithSale(periodicna, vanredna);
    let html = osobe.map(red => {
            return `<tr> <td>${red.name}</td>
                <td>${red.place}</td> </tr>`;
        }).join('\n');
    html = '<tr><th>Osoblje</th><th>Prostorija</th></tr>' + html;
    document.getElementById('tabela').innerHTML = html;
}

async function matchOsobeWithSale(periodicna, vanredna) {
    periodicna.forEach(zauzece => {
        let converted = convertPeriodicnoToVanredna(zauzece);
        vanredna = [...vanredna, ...converted];
    });
    const datum = new Date().getDate() + '.' + (new Date().getMonth() + 1) + '.' + new Date().getFullYear();
    let vrijeme = (new Date().getHours()) + ':' + (new Date().getMinutes()) + ':' + (new Date().getSeconds());
    vanredna = vanredna.filter(zauzece => {
        return zauzece.datum === datum && zauzece.pocetak <= vrijeme && zauzece.kraj >= vrijeme;
    });
    let osobe = await Pozivi.getOsoblje();
    osobe = osobe.osoblje.map(osoba => {
        let result = {
            name: osoba.ime + ' ' + osoba.prezime,
            place: 'U kancelariji'
        };
        vanredna.forEach(zauzece => {
            if (osoba.id === zauzece.predavac.value) {
                result.place = zauzece.naziv;
            }
        });
        return result;
    });
    return osobe ;
}

function convertPeriodicnoToVanredna(periodicno){
    let zauzeca = [];
    if(periodicno.semestar === 'zimski'){
        for(let mjesec = 9; mjesec<12; mjesec++){
            zauzeca.push(...makeZauzeca(mjesec, periodicno));
        }
        //ovdje treba i za januar
        zauzeca.push(...makeZauzeca(0,periodicno));
    }else if(periodicno.semestar === 'ljetni'){
        for(let mjesec = 1; mjesec<6; mjesec++){
            zauzeca.push(...makeZauzeca(mjesec,periodicno));
        }
    }
    return zauzeca;
}

function makeZauzeca(mjesec,zauzece){
    const godina = new Date().getFullYear();
    const broj_dana = new Date(godina, mjesec+1,0).getDate();
    zauzeca = [];
    for(let i = 1; i<=broj_dana; i++){
        let dan = new Date(godina, mjesec,i).getDay() - 1;
        if (dan < 0)dan = 6;
        if (dan == zauzece.dan){
            zauzeca.push({
                datum:`${i}.${mjesec+1}.${godina}`,
                pocetak:zauzece.pocetak,
                kraj:zauzece.kraj,
                naziv:zauzece.naziv,
                predavac:zauzece.predavac
            })
        }
    }
    return zauzeca;
}