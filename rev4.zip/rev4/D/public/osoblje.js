window.onload= function ()
{
	Pozivi.ucitajSaleO(function (data)
	{
		
		
	});
	

}