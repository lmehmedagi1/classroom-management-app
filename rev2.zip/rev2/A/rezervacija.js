const naziv_mjeseca=['Januar', 'Februar', 'Mart', 'April', 'Maj', 'Juni', 'Juli', 'August', 'Septembar', 'Oktobar', 'Novembar', 'Decembar'];
var mjesec=new Date().getMonth();

var tabela = document.getElementById('kalendar');
var mjesec_p=document.getElementById('mjesec');
mjesec_p.innerHTML=naziv_mjeseca[mjesec];
Kalendar.iscrtajKalendar(tabela, mjesec);

class periodicna {
    constructor(dan, semestar, pocetak, kraj, naziv, profesor) {
        this.dan=dan;
        this.semestar=semestar;
        this.pocetak=pocetak;
        this.kraj=kraj;
        this.naziv=naziv;
        this.profesor=profesor;
    }
}

class vanredna {
    constructor(datum, pocetak, kraj, naziv, profesor) {
        this.datum=datum;
        this.pocetak=pocetak;
        this.kraj=kraj;
        this.naziv=naziv;
        this.profesor=profesor;
    }
}

ucitajioboji();

function izmjena() {
    Kalendar.iscrtajKalendar(tabela, mjesec);
    ucitajioboji();
}

function prethodni() {
    document.getElementById('sljedeci').disabled=false;
    mjesec--;
    if(mjesec==0) document.getElementById('prethodni').disabled=true;
    mjesec_p.innerHTML=naziv_mjeseca[mjesec];
    Kalendar.iscrtajKalendar(tabela, mjesec);
    ucitajioboji();
}

function sljedeci() {
    document.getElementById('prethodni').disabled=false;
    mjesec++;
    if(mjesec==11) document.getElementById('sljedeci').disabled=true;
    mjesec_p.innerHTML=naziv_mjeseca[mjesec];
    Kalendar.iscrtajKalendar(tabela, mjesec);
    ucitajioboji();
}

function ucitajioboji() {
    var periodicno1= new periodicna(1,'zimski','12:00','14:00','1-02', 'prof. Vensada');
    var periodicno2= new periodicna(0,'zimski','10:00','12:00','0-02', 'prof. Vensada');
    var periodicno3= new periodicna(2,'zimski','09:00','10:30','0-01', 'prof. Vensada');
    var periodicno4= new periodicna(3,'ljetni','18:00','19:00','VA1', 'prof. Vensada');
    var periodicno5= new periodicna(4,'ljetni','15:00','16:00','VA2', 'prof. Vensada');
    var periodicno6= new periodicna(5,'ljetni','15:30','17:30','MA', 'prof. Vensada');
    var periodicno7= new periodicna(6,'zimski','12:30','14:00','EE1', 'prof. Vensada');
    var periodicne=[periodicno1, periodicno2, periodicno3, periodicno4, periodicno5, periodicno6, periodicno7];
    var vanredno1=new vanredna('06.11.2019','12:00','14:00','1-02','prof. Vensada');
    var vanredno2=new vanredna('05.10.2019','10:00','12:00','0-02','prof. Vensada');
    var vanredno3=new vanredna('13.12.2019','09:00','10:30','0-01','prof. Vensada');
    var vanredno4=new vanredna('06.11.2019','18:00','19:00','VA1','prof. Vensada');
    var vanredno5=new vanredna('10.11.2019','15:00','16:00','VA2','prof. Vensada');
    var vanredno6=new vanredna('06.11.2019','10:00','14:00','MA','prof. Vensada');
    var vanredno7=new vanredna('18.11.2019','12:30','14:00','EE1','prof. Vensada');
    var vanredne=[vanredno1, vanredno2, vanredno3, vanredno4, vanredno5, vanredno6,vanredno7];
    Kalendar.ucitajPodatke(periodicne, vanredne);
    var sala=document.getElementById('sala');
    var poc=document.getElementById('pocetak');
    var kraj=document.getElementById('kraj');
    Kalendar.obojiZauzeca(tabela,mjesec, sala.options[sala.selectedIndex].value, poc.value, kraj.value);
} 