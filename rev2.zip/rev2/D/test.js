let assert = chai.assert;
describe('kalendar', function() {
    describe('iscrtajKalendar()', function() {
        it('zadnji dan je subota za mjesec', function() {
            Kalendar.iscrtajKalendar(document.getElementsByClassName("kalendar"), globDatum.getMonth());
            var jeli = false;
            kalendarRef = document.getElementsByClassName("kalendar");
            var elementiOvogaKalendara = kalendarRef[0].children;
            var elementiSedmice1 = elementiOvogaKalendara[1].children;
            var elementiSedmice2 = elementiOvogaKalendara[2].children;
            var elementiSedmice3 = elementiOvogaKalendara[3].children;
            var elementiSedmice4 = elementiOvogaKalendara[4].children;
            var elementiSedmice5 = elementiOvogaKalendara[5].children;
            var elementiSedmice6 = elementiOvogaKalendara[6].children;
            var names = document.querySelectorAll('li hr');


            if (names[35].style.border == "none") {
                jeli = true;
            }






            assert.equal(jeli, true, "Subota");
        });

        it('petak bi trebao bit iprvi dan', function() {
            Kalendar.iscrtajKalendar(document.getElementsByClassName("kalendar"), globDatum.getMonth());
            var jeli = false;
            kalendarRef = document.getElementsByClassName("kalendar");
            var elementiOvogaKalendara = kalendarRef[0].children;
            var elementiSedmice1 = elementiOvogaKalendara[1].children;
            var elementiSedmice2 = elementiOvogaKalendara[2].children;
            var elementiSedmice3 = elementiOvogaKalendara[3].children;
            var elementiSedmice4 = elementiOvogaKalendara[4].children;
            var elementiSedmice5 = elementiOvogaKalendara[5].children;
            var elementiSedmice6 = elementiOvogaKalendara[6].children;
            var names = document.querySelectorAll('li hr');


            if (names[3].style.border == "none") {
                jeli = true;
            }


            assert.equal(jeli, true, "Prvi petak");
        });


        it('valja li Januar', function() {
            Kalendar.iscrtajKalendar(document.getElementsByClassName("kalendar"), 0);
            var jeli = false;
            kalendarRef = document.getElementsByClassName("kalendar");
            var elementiOvogaKalendara = kalendarRef[0].children;
            var elementiSedmice1 = elementiOvogaKalendara[1].children;
            var elementiSedmice2 = elementiOvogaKalendara[2].children;
            var elementiSedmice3 = elementiOvogaKalendara[3].children;
            var elementiSedmice4 = elementiOvogaKalendara[4].children;
            var elementiSedmice5 = elementiOvogaKalendara[5].children;
            var elementiSedmice6 = elementiOvogaKalendara[6].children;
            var names = document.querySelectorAll('li hr');


            if (names[0].style.border == "none" && names[33].style.border == "none") {
                jeli = true;
            }



            assert.equal(jeli, true, "Sve u redu");
        });

        it('30 za april', function() {
            Kalendar.iscrtajKalendar(document.getElementsByClassName("kalendar"), 3);
            var jeli = false;
            kalendarRef = document.getElementsByClassName("kalendar");
            var elementiOvogaKalendara = kalendarRef[0].children;
            var elementiSedmice1 = elementiOvogaKalendara[1].children;
            var elementiSedmice2 = elementiOvogaKalendara[2].children;
            var elementiSedmice3 = elementiOvogaKalendara[3].children;
            var elementiSedmice4 = elementiOvogaKalendara[4].children;
            var elementiSedmice5 = elementiOvogaKalendara[5].children;
            var elementiSedmice6 = elementiOvogaKalendara[6].children;
            var names = document.querySelectorAll('li hr');


            if (names[31].style.border == "none") {
                jeli = true;
            }

            assert.equal(jeli, true, "Broj dana ");
        });

        it('ima li 31 dan za decembar', function() {
            Kalendar.iscrtajKalendar(document.getElementsByClassName("kalendar"), 11);
            var jeli = false;
            kalendarRef = document.getElementsByClassName("kalendar");
            var elementiOvogaKalendara = kalendarRef[0].children;
            var elementiSedmice1 = elementiOvogaKalendara[1].children;
            var elementiSedmice2 = elementiOvogaKalendara[2].children;
            var elementiSedmice3 = elementiOvogaKalendara[3].children;
            var elementiSedmice4 = elementiOvogaKalendara[4].children;
            var elementiSedmice5 = elementiOvogaKalendara[5].children;
            var elementiSedmice6 = elementiOvogaKalendara[6].children;
            var names = document.querySelectorAll('li hr');


            if (names[38].style.border == "none") {
                jeli = true;
            }

            assert.equal(jeli, true, "Broj dana treba biti 31");
        });



    });

});