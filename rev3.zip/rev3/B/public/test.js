let assert = chai.assert;
describe('Kalendar', function() {
 describe('ucitajPodatke()', function() {
   describe('obojiZauzeca()', function() {
     it('Pozivanje obojiZauzeca kada podaci nisu učitani: očekivana vrijednost da se ne oboji niti jedan dan', function() {

       let periodicna3 = {
         dan: 0,
         semestar: "ljetni",
         pocetak: "6:00",
         kraj: "9:00",
         naziv: "1-03",
         predavac: "HAimd"
       };
       let vanredna3 = {
         datum: "03.11.2019",
         pocetak: "17:00",
         kraj: "19:00",
         naziv: "0-06",
         predavac: "Ado"
       };
       let noviPeriodicna = [], noviVanredna = [];
       noviPeriodicna.push(periodicna3);
       noviVanredna.push(vanredna3);
       //Kalendar.ucitajPodatke(noviPeriodicna, noviVanredna);
       Kalendar.obojiZauzeca(document.getElementsByClassName("calendar")[0], 12, "1-15", "12:00", "13:30");

       let flag = true;
       let slobodne = document.getElementsByClassName("slobodna");
       for(let slbna of Array.from(slobodne)){
         if(slbna.style.backgroundColor==="red") flag=false;
       }
       assert.equal(flag, true, "Nema obojenih celija");
     });

     it('Pozivanje iscrtajKalendar za mjesec sa 31 dan: očekivano je da se prikaže 31 dan', function() {

     });

   });
 });
});
