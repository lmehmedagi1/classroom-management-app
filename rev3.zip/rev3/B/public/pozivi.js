let Pozivi = (function(){
  //
  //ovdje idu privatni atributi
  //
  function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj){
  //implementacija ide ovdje
  }
  function ucitajPodatkeImpl(periodicna, ​vanredna​){
  //implementacija ide ovdje
  }
  function iscrtajKalendar(kalendarRef, mjesec){
  //implementacija ide ovdje
  }
  return {
    obojiZauzeca: obojiZauzecaImpl,
    ucitajPodatke: ucitajPodatkeImpl,
    iscrtajKalendar: iscrtajKalendarImpl
  }
}());

//primjer korištenja modula
//Kalendar.obojiZauzeca(document.getElementById(“kalendar”),1,”1-15”,”12:00”,”13:30”);
