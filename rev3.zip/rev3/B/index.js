const express = require("express");
const bodyParser = require("body-parser");
const app = express();
app.use(express.static("public"));

app.get("/", function(req, res){
  res.sendFile(__dirname + "/public/pocetna.html");
});



app.listen(8080, function(){
  console.log("Server has started!")
});



//http://localhost:8080/
