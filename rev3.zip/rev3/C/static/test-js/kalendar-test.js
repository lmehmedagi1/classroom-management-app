const assert = chai.assert;
const describe = Mocha.describe;
const it = Mocha.it;

const _ = (idClassOrName) => {
    switch (idClassOrName[0]) {
        case '#':
            return document.getElementById(idClassOrName.substring(1));
        case '.':
            return document.getElementsByClassName(idClassOrName.substring(1));
        default:
            return document.getElementsByName(idClassOrName);
    }
};

const placeholderPeriodicna = [
    {
        dan: 0,
        semestar: 'zimski',
        pocetak: '09:00',
        kraj: '10:30',
        naziv: 'Periodicno 1',
        predavac: 'Profesor 1'
    },
    {
        dan: 3,
        semestar: 'zimski',
        pocetak: '19:00',
        kraj: '20:30',
        naziv: 'Periodicno 2',
        predavac: 'Profesor 2'
    },
    {
        dan: 2,
        semestar: 'zimski',
        pocetak: '10:00',
        kraj: '14:15',
        naziv: 'Periodicno 3',
        predavac: 'Profesor 3'
    }
];
const placeholderVanredna = [
    {
        datum: '20.11.2019',
        pocetak: '15:00',
        kraj: '15:15',
        naziv: 'Vanredno 1',
        predavac: 'Profesor 1'
    },
    {
        datum: '21.11.2019',
        pocetak: '15:00',
        kraj: '15:15',
        naziv: 'Vanredno 2',
        predavac: 'Profesor 2'
    }
];

describe('Kalendar', function() {
    describe('iscrtajKalendar()', function() {
        it('should draw 30 days for months with 30 days', function () {
            _('#ispis').innerHTML = `<table id="kalendar"></table>`;

            Kalendar.iscrtajKalendar(_('#kalendar'), 8);

            assert.equal(_('#kalendar').getElementsByClassName('dan').length, 30, 'Kalendar mora imati 30 dana!');
        });

        it('should draw 31 days for months with 31 days', function () {
            _('#ispis').innerHTML = `<table id="kalendar"></table>`;

            Kalendar.iscrtajKalendar(_('#kalendar'), 9);

            assert.equal(_('#kalendar').getElementsByClassName('dan').length, 31, 'Kalendar mora imati 31 dan!');
        });

        it('should draw november 2019 with friday as the first', function () {
            _('#ispis').innerHTML = `<table id="kalendar"></table>`;

            Kalendar.iscrtajKalendar(_('#kalendar'), 10);

            const prviDan = _('.dan')[0];
            const prvaSedmica = Array.from(prviDan.parentElement.parentElement.getElementsByTagName('td'));

            assert.equal(prvaSedmica[4].getAttribute('class'), 'sala', 'Petak je prvi dan novembra.');
            assert.notEqual(prvaSedmica[3].getAttribute('class'), 'sala', 'Cetvrtak nije u novembru.');
        });

        it('should draw november 2019 with saturday as the 30th', function () {
            _('#ispis').innerHTML = `<table id="kalendar"></table>`;

            Kalendar.iscrtajKalendar(_('#kalendar'), 10);

            const zadnjiDan = _('.dan')[29];
            const zadnjaSedmica = Array.from(zadnjiDan.parentElement.parentElement.getElementsByTagName('td'));

            assert.equal(zadnjaSedmica[5].getAttribute('class'), 'sala', 'Subota je zadnji dan novembra.');
            assert.notEqual(zadnjaSedmica[6].getAttribute('class'), 'sala', 'Nedjelja nije u novembru.');
        });

        it('should draw january 2019 with 31 days, starting with tuesday', function () {
            _('#ispis').innerHTML = `<table id="kalendar"></table>`;

            Kalendar.iscrtajKalendar(_('#kalendar'), 0);

            const prviDan = _('.dan')[0];
            const prvaSedmica = Array.from(prviDan.parentElement.parentElement.getElementsByTagName('td'));

            assert.equal(prvaSedmica[1].getAttribute('class'), 'sala', 'Utorak je prvi dan januara.');
            assert.notEqual(prvaSedmica[0].getAttribute('class'), 'sala', 'Ponedjeljak nije u januaru.');
        });

        it('should draw name of month atop the calendar', function () {
            _('#ispis').innerHTML = `<table id="kalendar"></table>`;

            Kalendar.iscrtajKalendar(_('#kalendar'), 10);

            assert.equal(_('#trenutni-mjesec').innerText, 'Novembar', 'Mjesec treba biti novembar.');
        });

        it('should draw the next month if the corresponding button is pressed', function () {
            _('#ispis').innerHTML = `<table id="kalendar"></table>`;

            Kalendar.iscrtajKalendar(_('#kalendar'), 10);

            _('#btn-next').click();

            assert.equal(_('#trenutni-mjesec').innerText, 'Decembar', 'Mjesec bi trebao biti decembar.');
        });

        it('should disable previous month button in january', function () {
           _('#ispis').innerHTML = `<table id="kalendar"></table>`;

           Kalendar.iscrtajKalendar(_('#kalendar'), 0);

           assert.isNotNull(_('#btn-prev').getAttribute('disabled'), 'Dugme za prelazak u prethodni mjesec bi trebalo biti neaktivno');
        });
    });
    describe('obojiZauzeca()', function () {
        it('should do nothing if data has not been loaded', function () {
            _('#ispis').innerHTML = `<table id="kalendar"></table>`;

            Kalendar.iscrtajKalendar(_('#kalendar'), 10);

            Kalendar.obojiZauzeca(_('#kalendar'), 10, 'AA', '00:00', '00:00');

            assert.isEmpty(_('.zauzeta'), 'Ne bi trebalo postojati nijedno zauzece');
        });

        it('should ignore duplicate values', function () {
            let periodicna = [...placeholderPeriodicna];

            assert.equal(periodicna.length, placeholderPeriodicna.length, 'Preuzeta su periodicna zauzeca');

            periodicna.push(placeholderPeriodicna[0]);

            assert.equal(periodicna.length, placeholderPeriodicna.length + 1, 'Imamo jedno zauzece vise');
            assert.equal(periodicna.filter(z => z.naziv === placeholderPeriodicna[0].naziv).length, 2, 'Imamo dva puta isto zauzece');

            _('#ispis').innerHTML = `<table id="kalendar"></table>`;

            Kalendar.ucitajPodatke(periodicna, []);
            Kalendar.iscrtajKalendar(_('#kalendar'), 10);
            Kalendar.obojiZauzeca(_('#kalendar'), 10, 'AA', '00:00', '00:00');

            assert.equal(_('.zauzeta').length, 13, 'Trebalo bi da imamo tacno 13 zauzeca - 4 ponedjeljka, 4 utorka i 5 subota');
        });

        it('should ignore days in other semesters for periodic occupations', function () {
            let periodicna = [...placeholderPeriodicna.map(p => {
                p.semestar = 'ljetni';
                return p;
            })];

            assert.isEmpty(periodicna.filter(p => p.semestar === 'zimski'), 'Ne bismo trebali imati zauzeca u zimskom semestru');

            _('#ispis').innerHTML = `<table id="kalendar"></table>`;

            Kalendar.ucitajPodatke(periodicna, []);
            Kalendar.iscrtajKalendar(_('#kalendar'), 10);
            Kalendar.obojiZauzeca(_('#kalendar'), 10, 'AA', '00:00', '00:00');

            assert.isEmpty(_('.zauzeta'), 'Trebalo bi da nemamo zauzeca, posto su sva u ljetnom semestru');
        });

        it('should ignore days in other months', function () {
            let vanredna = [...placeholderVanredna];

            assert.equal(vanredna.length, 2, 'Trebalo bi da imamo dva vanredna zauzeca');
            assert.isEmpty(vanredna.filter(v => v.datum.match(/\d{2}\.(\d{2})\.\d{4}/)[1] === '10'), 'Ne bi trebalo biti zauzeca za oktobar');

            _('#ispis').innerHTML = `<table id="kalendar"></table>`;

            Kalendar.ucitajPodatke([], vanredna);
            Kalendar.iscrtajKalendar(_('#kalendar'), 9);
            Kalendar.obojiZauzeca(_('#kalendar'), 9, 'AA', '00:00', '00:00');

            assert.isEmpty(_('.zauzeta'), 'Trebalo bi da nemamo zauzeca, posto su sva u novembru');
        });

        it('should paint all days in a month when all days are occupied', function () {
            let periodicna = [];
            for (let i = 0; i < 7; i++)
                periodicna.push({
                    dan: i,
                    semestar: 'zimski',
                    pocetak: '09:00',
                    kraj: '10:30',
                    naziv: 'Periodicno 1',
                    predavac: 'Profesor 1'
                });

            assert.equal(periodicna.length, 7, 'Trebalo bi da imamo sedam periodicnih zauzeca');

            _('#ispis').innerHTML = `<table id="kalendar"></table>`;

            Kalendar.ucitajPodatke(periodicna, []);
            Kalendar.iscrtajKalendar(_('#kalendar'), 10);
            Kalendar.obojiZauzeca(_('#kalendar'), 10, 'AA', '00:00', '00:00');

            assert.isEmpty(_('.slobodna'), 'Trebalo bi da nemamo slobodnih sala');
        });

        it('should be idempotent - multiple calls with the same input should produce the same output', function () {
            let periodicna = [...placeholderPeriodicna];
            let vanredna = [...placeholderVanredna];

            _('#ispis').innerHTML = `<table id="kalendar"></table>`;

            Kalendar.ucitajPodatke(periodicna, vanredna);
            Kalendar.iscrtajKalendar(_('#kalendar'), 10);
            Kalendar.obojiZauzeca(_('#kalendar'), 10, 'AA', '00:00', '00:00');

            const kalendarHTML = _('#kalendar').innerHTML;

            Kalendar.obojiZauzeca(_('#kalendar'), 10, 'AA', '00:00', '00:00');

            assert.equal(_('#kalendar').innerHTML, kalendarHTML, 'Staro i novo stanje trebaju biti isti');
        });

        it('should refresh all days upon data reload', function () {
            let vanredna = [...placeholderVanredna];

            _('#ispis').innerHTML = `<table id="kalendar"></table>`;

            Kalendar.ucitajPodatke([], vanredna);
            Kalendar.iscrtajKalendar(_('#kalendar'), 10);
            Kalendar.obojiZauzeca(_('#kalendar'), 10, 'AA', '00:00', '00:00');

            assert.equal(_('.zauzeta').length, 2, 'Imamo dva zauzeca');

            vanredna[0] = Object.assign(vanredna[0], { datum: '10.11.2019' });

            Kalendar.ucitajPodatke([], vanredna);
            Kalendar.obojiZauzeca(_('#kalendar'), 10, 'AA', '00:00', '00:00');

            assert.equal(_('.zauzeta').length, 2, 'Imamo dva zauzeca');

            vanredna.push({
                datum: '20.11.2019',
                pocetak: '15:00',
                kraj: '15:15',
                naziv: 'Vanredno 3',
                predavac: 'Profesor 3'
            });

            Kalendar.ucitajPodatke([], vanredna);
            Kalendar.obojiZauzeca(_('#kalendar'), 10, 'AA', '00:00', '00:00');

            assert.equal(_('.zauzeta').length, 3, 'Imamo tri zauzeca');
        });

        it('should paint single dates as occupied', function () {
            let vanredna = [{
                datum: '13.11.2019',
                pocetak: '00:00',
                kraj: '00:00',
                naziv: 'Vanredno',
                predavac: 'Profesor'
            }];

            _('#ispis').innerHTML = `<table id="kalendar"></table>`;

            Kalendar.ucitajPodatke([], vanredna);
            Kalendar.iscrtajKalendar(_('#kalendar'), 10);
            Kalendar.obojiZauzeca(_('#kalendar'), 10, 'AA', '00:00', '00:00');

            assert.equal(_('.zauzeta').length, 1, 'Samo jedna sala bi trebala biti zauzeta');
            assert.equal(_('.slobodna').length, 29, 'Trebalo bi da imamo ostalih 29 dana slobodne sale');
        });

        it('should paint no days if no days are occupied', function () {
            let periodicna = [];
            let vanredna = [];

            _('#ispis').innerHTML = `<table id="kalendar"></table>`;

            Kalendar.ucitajPodatke(periodicna, vanredna);
            Kalendar.iscrtajKalendar(_('#kalendar'), 10);
            Kalendar.obojiZauzeca(_('#kalendar'), 10, 'AA', '00:00', '00:00');

            assert.isEmpty(_('.zauzeta'), 'Nijedna sala ne bi trebala biti zauzeta');
            assert.equal(_('.slobodna').length, 30, 'Trebalo bi da imamo svih 30 dana slobodne sale');

            _('#ispis').innerHTML = '';
        });
    });
});
