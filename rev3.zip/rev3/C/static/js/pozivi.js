const Pozivi = (function () {
    const BASE_URL = 'http://localhost:8080';

    function dohvatiRezervacije(callback) {
        let xhttp = new XMLHttpRequest();

        xhttp.onreadystatechange = () => {
            if (xhttp.readyState === 4 && xhttp.status === 200)
                callback(JSON.parse(xhttp.response));
        };

        xhttp.open('GET', `${BASE_URL}/zauzeca`);
        xhttp.send();
    }

    function pokusajRezervisati(zauzece, callback) {
        let xhttp = new XMLHttpRequest();

        xhttp.onreadystatechange = () => {
            if (xhttp.readyState === 4 && xhttp.status === 200) {
                const body = JSON.parse(xhttp.response);
                if (body.poruka)
                    alert(body.poruka);
                else if (body.periodicna && body.vanredna)
                    callback(body);
                else {
                    alert('Doslo je do greske!');
                    console.error(body);
                }

            }
        };

        xhttp.open('POST', `${BASE_URL}/zauzeca`);
        xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xhttp.send(JSON.stringify(zauzece));
    }

    function brojSlika(callback) {
        let xhttp = new XMLHttpRequest();

        xhttp.onreadystatechange = () => {
            if (xhttp.readyState === 4 && xhttp.status === 200) {
                const body = JSON.parse(xhttp.response);
                if (!body.ukupno)
                    callback(0);
                else
                    callback(body.ukupno);
            }
        };

        xhttp.open('GET', `${BASE_URL}/slike/ukupno`);
        xhttp.send();
    }

    function dohvatiSlike(preuzeto, callback) {
        let xhttp = new XMLHttpRequest();

        xhttp.onreadystatechange = () => {
            if (xhttp.readyState === 4 && xhttp.status === 200) {
                const body = JSON.parse(xhttp.response);
                callback(body.slike);
            }
        };

        xhttp.open('GET', `${BASE_URL}/slike/${preuzeto}`);
        xhttp.send();
    }

    return {
        dohvatiRezervacije: dohvatiRezervacije,
        pokusajRezervisati: pokusajRezervisati,
        brojSlika: brojSlika,
        dohvatiSlike: dohvatiSlike
    }
})();
