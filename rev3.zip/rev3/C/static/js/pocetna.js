const brojPoStranici = 3;
let slike = [];
let ukupnoSlika = 0;
let trenutnaPrva = 0;

function init() {
    document.getElementById('btn-prev').disabled = true;

    Pozivi.brojSlika((broj) => {
        ukupnoSlika = broj;
        mozdaDohvati(() => prikaziSlike());
    });
}

function mozdaDohvati(callback) {
    if (slike.length < ukupnoSlika)
        Pozivi.dohvatiSlike(slike.length, (nove) => { slike.push(...nove); callback(); });
    else
        callback();
}

function naprijed() {
    mozdaDohvati(() => {
        document.getElementById('btn-prev').disabled = false;

        trenutnaPrva = trenutnaPrva + brojPoStranici;

        if (trenutnaPrva + 1 >= ukupnoSlika) {
            trenutnaPrva = ukupnoSlika - brojPoStranici;
            document.getElementById('btn-next').disabled = true;
        }

        prikaziSlike();
    });
}

function nazad() {
    document.getElementById('btn-next').disabled = false;

    trenutnaPrva = trenutnaPrva >= brojPoStranici ? trenutnaPrva - brojPoStranici : 0;

    if (trenutnaPrva === 0)
        document.getElementById('btn-prev').disabled = true;

    prikaziSlike();
}

function prikaziSlike() {
    document.getElementById('slika-1').src = slike[trenutnaPrva];
    document.getElementById('slika-2').src = slike[trenutnaPrva + 1];
    document.getElementById('slika-3').src = slike[trenutnaPrva + 2];
}

const originalOnLoad = window.onload;

window.onload = (e) => {
    if (typeof originalOnLoad === 'function')
        originalOnLoad(e);

    document.getElementById('btn-prev').addEventListener('click', nazad);
    document.getElementById('btn-next').addEventListener('click', naprijed);

    init();
};
