function trenutniMjesec() {
    const matches = document.getElementById('trenutni-mjesec').getAttribute('class').match(/mjesec_(\d+)/);
    return matches != null ? matches[1] : new Date().getMonth();
}

function trenutniSemestar() {
    const mjesec = trenutniMjesec();
    if (mjesec > 0 && mjesec < 6)
        return 'ljetni';
    else if (mjesec >= 6 && mjesec < 9)
        throw RangeError('Nastava se ne odrzava u julu, augustu i septembru.');

    return 'zimski';
}

function forma() {
    return {
        sala: (() => {
            let select = document.getElementById('form-input-sala');
            return select.options[select.selectedIndex].text;
        })(),
        periodicno: document.getElementById('form-input-periodic').checked,
        pocetak: document.getElementById('form-input-time-from').value,
        kraj: document.getElementById('form-input-time-to').value
    }
}

function render(zauzeca) {
    Kalendar.ucitajPodatke(zauzeca.periodicna, zauzeca.vanredna);

    try {
        ispisi(trenutniMjesec());
    } catch (e) {
        ispisi();
    }
}

function ispisi(mjesec = new Date().getMonth()) {
    Kalendar.iscrtajKalendar(document.getElementById('kalendar-desktop'), mjesec);
    Kalendar.obojiZauzeca(document.getElementById('kalendar-desktop'), mjesec, forma().sala, forma().pocetak, forma().kraj);

    document.getElementById('btn-prev').addEventListener('click', () => ispisi(mjesec - 1));
    document.getElementById('btn-next').addEventListener('click', () => ispisi(mjesec + 1));

    for (let el of document.getElementsByClassName('sala'))
        el.addEventListener('click', function () {
            if (this.getElementsByClassName('zauzeta').length > 0)
                console.log('Termin zauzet!');

            const dan = parseInt(this.getElementsByClassName('dan')[0].innerText.toString());

            if (confirm('Da li želite rezervisati ovaj termin?'))
                zauzmi(dan);
        });
}

function zauzmi(dan) {
    const mjesec = trenutniMjesec();
    const datum = new Date(mjesec < 10 ? 2020 : 2019, mjesec, dan);
    const osnovno = {
        pocetak: forma().pocetak,
        kraj: forma().kraj,
        naziv: forma().sala,
        predavac: 'Profesor'
    };
    const zauzece = forma().periodicno ?
        {
            dan: datum.getDay() === 0 ? 6 : datum.getDay() - 1,
            semestar: trenutniSemestar(),
            ...osnovno
        } : {
            datum: `${parseInt(dan) < 10 ? '0' + dan : dan}.${datum.getMonth() + 1}.${datum.getUTCFullYear()}`,
            ...osnovno
        };

    Pozivi.pokusajRezervisati(zauzece, render);
}

const originalOnLoad = window.onload;

window.onload = (e) => {
    if (typeof originalOnLoad === 'function')
        originalOnLoad(e);

    Pozivi.dohvatiRezervacije(render);
};
