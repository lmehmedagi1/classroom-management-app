const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static('html'));
app.use(express.static('static'));

const PATH_ZAUZECA = 'zauzeca.json';
const PATH_SLIKE = 'static/img/';

app.get('/', (req, res) => {
    res.redirect('pocetna.html');
});

app.get('/zauzeca', (req, res) => {
    fs.readFile(PATH_ZAUZECA, (err, data) => {
        if (err) {
            res.json({
                error: `${err.code}: Error opening file.`,
                name: err.name,
                message: err.message,
            });
            return;
        }

        try {
            res.json(JSON.parse(data.toString()));
        } catch (e) {
            fs.writeFileSync(PATH_ZAUZECA, JSON.stringify({vanredna: [], periodicna: []}));
            res.json({vanredna: [], periodicna: []});
        }
    });
});

function poklapanjeVremena(prvi, drugi) {
    const prviPocetak = parseInt(prvi.pocetak.replace(':', ''));
    const prviKraj = parseInt(prvi.kraj.replace(':', ''));
    const drugiPocetak = parseInt(drugi.pocetak.replace(':', ''));
    const drugiKraj = parseInt(drugi.kraj.replace(':', ''));

    return drugiPocetak > drugiKraj || !((drugiPocetak >= prviKraj && drugiKraj > prviKraj) || (drugiKraj <= prviPocetak && drugiPocetak < prviPocetak));
}

const DANI = ['ponedjeljak', 'utorak', 'srijeda', 'četvrtak', 'petak', 'subota', 'nedjelja'];

function dodajPeriodicno(zauzece) {
    const trenutna = JSON.parse(fs.readFileSync(PATH_ZAUZECA).toString());
    const ispitajPoklapanje = (prvi, drugi) => prvi.dan === drugi.dan && poklapanjeVremena(prvi, drugi);

    if (trenutna.periodicna.some(periodicno => ispitajPoklapanje(periodicno, zauzece)))
        return {poruka: `Nije moguće rezervisati salu ${zauzece.naziv} za ${DANI[zauzece.dan]} i termin od ${zauzece.pocetak} do ${zauzece.kraj}!`};

    const data = {
        periodicna: [
            zauzece,
            ...trenutna.periodicna
        ],
        vanredna: [...trenutna.vanredna]
    };

    fs.writeFileSync(PATH_ZAUZECA, JSON.stringify(data));

    return data;
}

function dodajVanredno(zauzece) {
    const trenutna = JSON.parse(fs.readFileSync(PATH_ZAUZECA).toString());
    const ispitajPoklapanje = (prvi, drugi) => prvi.datum === drugi.datum && poklapanjeVremena(prvi, drugi);

    if (trenutna.vanredna.some(vanredno => ispitajPoklapanje(vanredno, zauzece)))
        return {poruka: `Nije moguće rezervisati salu ${zauzece.naziv} za navedeni datum ${zauzece.datum} i termin od ${zauzece.pocetak} do ${zauzece.kraj}!`};

    const data = {
        periodicna: [...trenutna.periodicna],
        vanredna: [
            zauzece,
            ...trenutna.vanredna
        ]
    };

    fs.writeFileSync(PATH_ZAUZECA, JSON.stringify(data));

    return data;
}

app.post('/zauzeca', (req, res) => {
    let novo = req.body;

    if (!!novo.dan && !!novo.semestar && !!novo.pocetak && !!novo.kraj && !!novo.naziv && !!novo.predavac) {
        res.json(dodajPeriodicno(novo));
    } else if (!!novo.datum && !!novo.pocetak && !!novo.kraj && !!novo.naziv && !!novo.predavac) {
        res.json(dodajVanredno(novo));
    } else {
        res.json({
            greska: 'Greska!',
            input: novo
        });
    }
});

app.get('/slike/ukupno', (req, res) => {
    fs.readdir(PATH_SLIKE, (err, slike) => {
        res.json({
            ukupno: err != null ? 0 : slike.filter(path => path.endsWith('.jpg') || path.endsWith('.jpeg') || path.endsWith('.png')).length
        });
    });
});

app.get('/slike/:preuzeto', (req, res) => {
    const brojPoStranici = 3;
    const preuzeto = parseInt(req.params.preuzeto);

    fs.readdir(PATH_SLIKE, (err, slike) => {
        if (err)
            res.json({
                greska: 'Greska!',
                input: preuzeto
            });

        const ukupnoSlika = slike.length;
        const preostaloSlika = ukupnoSlika - preuzeto;

        if (preostaloSlika > 0)
            res.json({
                slike: slike.slice(preuzeto, preostaloSlika >= brojPoStranici ? preuzeto + brojPoStranici : preuzeto + preostaloSlika).map(path => `img/${path}`)
            });
        else
            res.json({
                slike: []
            });
    });
});

app.listen(8080);
