const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
var fs = require("fs");

var app = express();

app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.get("/ucitaj_rezervacije", (req,res) => {
  fs.readFile("zauzeca.json", (err,data) => {
    if (err) throw err;
    var zaduzenja = JSON.parse(data);
    res.json(zaduzenja);
  });
});

var slike = ["http://images.unsplash.com/reserve/bOvf94dPRxWu0u3QsPjF_tree.jpg?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjEyMDd9",
          "http://images.unsplash.com/reserve/bOvf94dPRxWu0u3QsPjF_tree.jpg?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjEyMDd9",
          "https://images.unsplash.com/photo-1500622944204-b135684e99fd?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80",
          "https://images.unsplash.com/photo-1442850473887-0fb77cd0b337?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80",
          "https://images.unsplash.com/photo-1433086966358-54859d0ed716?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80",
          "https://images.unsplash.com/photo-1577180234245-9d43488a6722?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjExMDk0fQ&w=1000&q=80",
          "https://images.unsplash.com/photo-1441239372925-ac0b51c4c250?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1000&q=80",
          "https://images.unsplash.com/photo-1433086966358-54859d0ed716?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80",
          "https://images.unsplash.com/photo-1542662565-7e4b66bae529?ixlib=rb-1.2.1&auto=format&fit=crop&w=428&h=214&q=60",
          "https://images.unsplash.com/photo-1500622944204-b135684e99fd?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80"];

app.get("/promjeni_slike", (req,res) => {
  var stranica = parseInt(req.query.page);

  var brojStranica = Math.ceil(slike.length/3);

  var response = {
    imaSljedecih: true,
    slike: []
  }

  if(stranica == brojStranica - 1)
    response.imaSljedecih = false;

  var pocetak = stranica * 3;
  var kraj = (stranica + 1) * 3 > slike.length ? slike.length : (stranica + 1) * 3;

  response.slike = slike.slice(pocetak, kraj);

  res.json(response);
});


app.get("/", (req,res)=>{
  res.sendFile("pocetna.html" , { root: (path.join(__dirname + "\\public")) })
});

app.get("/unos",(req,res)=>{
  res.sendFile("unos.html" , { root: (path.join(__dirname + "\\public")) });
})

app.get("/pocetna",(req,res)=>{
  res.sendFile("pocetna.html" , { root: (path.join(__dirname + "\\public")) });
})

app.get("/rezervacija",(req,res)=>{
  res.sendFile("rezervacija.html" , { root: (path.join(__dirname + "\\public")) });
})

app.get("/sale",(req,res)=>{
  res.sendFile("sale.html" , { root: (path.join(__dirname + "\\public")) });
})

// app.get("/:nazivDokumenta", function (req, res) {
//   res.sendFile(req.params["nazivDokumenta"] + ".html" , { root: (path.join(__dirname + "\\public")) });
// });

app.listen(8080, ()=>{console.log("Server running!");})