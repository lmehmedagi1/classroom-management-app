var Pozivi = (function(){

    function kreirajSlike (niz) {
        niz.forEach((link) => {
            var div = document.createElement("DIV");
            div.setAttribute('class', 'gridItem');
            var img = document.createElement("IMG");
            img.setAttribute('src', link);
            document.getElementsByClassName("sadrzaj")[0].appendChild(div).appendChild(img);
        });
    }
    function kreirajButtonContainer(){
        
    };

  function preuzmiRezervacije(kalendar, mjesec){
      var ajax = new XMLHttpRequest();
      ajax.open("GET","/ucitaj_rezervacije");
      ajax.onload = function(){
          if(ajax.status === 200 && ajax.readyState === 4){
            var podaci = JSON.parse(ajax.responseText);

            console.log(podaci);
            
            Kalendar.ucitajPodatke(podaci.periodicna, podaci.vanredna);
            Kalendar.obojiZauzeca(kalendar, mjesec, 'VA', '12:00', '14:00');
          }
      }
      ajax.send();
  }
  
  function ucitajSlike(event,stranica){

    var ajax = new XMLHttpRequest();
    ajax.open("GET","/promjeni_slike?action="+event+"&page="+stranica);
    ajax.onload = function(){
        if(ajax.status === 200 && ajax.readyState === 4){
          var rezultati = JSON.parse(ajax.responseText);
          console.log(rezultati.imaSljedecih);
          if (rezultati.imaSljedecih!=true){
            document.getElementsByClassName("sadrzaj")[0].innerHTML = "";
            kreirajSlike(rezultati.slike);
            var buttonContainer = "";
            buttonContainer = document.createElement("DIV");
            buttonContainer.setAttribute('class', 'buttonContainer');
            var prethodniBtn = document.createElement("BUTTON");
            prethodniBtn.innerHTML = "Prethodni";
            prethodniBtn.addEventListener('click', klikPrethodni);
            buttonContainer.appendChild(prethodniBtn);
            document.getElementsByClassName("sadrzaj")[0].appendChild(buttonContainer);
          }
          else if (stranica == 0 && event == "prethodni"){
            document.getElementsByClassName("sadrzaj")[0].innerHTML = "";
            kreirajSlike(rezultati.slike);
            var buttonContainer = "";
            buttonContainer = document.createElement("DIV");
            buttonContainer.setAttribute('class', 'buttonContainer');
            var slijedeciBtn = document.createElement("BUTTON");
            slijedeciBtn.innerHTML = "Slijedeci";
            slijedeciBtn.addEventListener('click', klikSlijedeci);
            buttonContainer.appendChild(slijedeciBtn);
            document.getElementsByClassName("sadrzaj")[0].appendChild(buttonContainer);
          }
          else {
            document.getElementsByClassName("sadrzaj")[0].innerHTML = "";
            kreirajSlike(rezultati.slike);
            var buttonContainer = "";
            buttonContainer = document.createElement("DIV");
            buttonContainer.setAttribute('class', 'buttonContainer');
            var prethodniBtn = document.createElement("BUTTON");
            prethodniBtn.innerHTML = "Prethodni";
            prethodniBtn.addEventListener('click', klikPrethodni);
            buttonContainer.appendChild(prethodniBtn);
            var slijedeciBtn = document.createElement("BUTTON");
            slijedeciBtn.innerHTML = "Slijedeci";
            slijedeciBtn.addEventListener('click', klikSlijedeci);
            buttonContainer.appendChild(slijedeciBtn);
            document.getElementsByClassName("sadrzaj")[0].appendChild(buttonContainer);
          }
        }
    }
    ajax.send();

  }
  return {
      preuzmiRezervacije: preuzmiRezervacije,
      ucitajSlike: ucitajSlike
  }
}());
  